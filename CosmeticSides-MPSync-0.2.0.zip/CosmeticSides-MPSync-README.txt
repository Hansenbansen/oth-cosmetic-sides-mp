Cosmetic Sides (multiplayer sync) - a MelonLoader mod for Over the Hill
=======================================================================

Based on Cosmetic Sides 0.1.2 by Ivan. Version 0.2.0 adds multiplayer synchronisation of
the side choices; everything else works as in the original.

What it does
- Separate "Side accessories - Left" and "Side accessories - Right" sections in the
  mechanic's Cosmetics menu for paired side accessories (e.g. a jerry can on one side,
  traction boards on the other). Left and right are the car's own sides facing forward.
- The preview camera moves to the selected side.
- Side choices are saved per vehicle and game profile in UserData/CosmeticSides/.
- Works alone or together with OTH.CosmeticStacker (stack several accessories per side).
- Multiplayer: players who also run this version see your exact left/right layout, late
  joiners included, and you see theirs. Players without the mod (or with the original
  0.1.2) see your equipped accessories on both sides, as before.

Requirements
- MelonLoader 0.7.3 or newer (https://github.com/LavaGang/MelonLoader/releases)

Install
1. Install MelonLoader into the game folder and start the game once.
2. Extract this zip into the game folder (OTH.CosmeticSides.dll ends up in "Mods").
   It replaces the original OTH.CosmeticSides.dll; keep only one copy. Existing side
   choices in UserData/CosmeticSides/ are kept.

Notes
- The host does not need the mod: side choices travel as a Photon player property that
  the game ignores.
- Uninstall: equip the same accessory on both sides (or remove paired side accessories),
  leave the mechanic, then delete Mods/OTH.CosmeticSides.dll. Without the mod, equipped
  accessories appear on both sides again.
